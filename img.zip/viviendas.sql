INSERT INTO viviendas (id_vivenda, tipo_vivenda, zona_vivenda, direccion_vivenda, ndormitorios_vivenda, precio_vivenda, `tanmaño_vivenda`, extras_vivenda, foto_vivenda, observaciones_vivenda) VALUES
  (1, 'casa', 'centro', '.', 2, 150000, 93, 'garage', 'file:///C:/xampp/htdocs/msql7/CASA4.html', NULL),
  (2, 'piso', 'macarena', '.', 3, 165000, 83, '.', 'file:///C:/xampp/htdocs/msql7/CASA3.html', NULL),
  (3, 'piso', 'nervion', '.', 2, 215000, 89, '.', 'file:///C:/xampp/htdocs/msql7/CASA2.html', NULL),
  (4, 'adosado', 'aljarafe', '.', 4, 300000, 130, 'Piscina,Jardin,Garage', 'file:///C:/xampp/htdocs/msql7/casa1.html', NULL),
  (5, 'piso', 'nervion', '.', 4, 360000, 125, 'garage', 'file:///C:/xampp/htdocs/msql7/CASA5.html', NULL),
  (6, 'chalet', 'aljaraf', '.', 4, 450000, 180, 'Piscina,Jardin,Garage', 'file:///C:/xampp/htdocs/msql7/casa.html', NULL);
